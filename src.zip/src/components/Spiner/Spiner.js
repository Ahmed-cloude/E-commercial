import React from 'react'
import './Spiner.css';

const Spiner =()=>{
    return(
        <div className='Spiner'>
            <div className='outSpiner'>
                <div className='inSpiner'></div>
            </div>
        </div>
    );
}

export default Spiner;