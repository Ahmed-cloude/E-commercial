import React from "react";

const Footer =()=>{
    const style={
        backgroundColor:"black",
        color:"white",
        textAlign:"center",
        padding:"30px 0px",
        margin:"0px"

    }
    return (
        <p style={style}>
            Store become easier by Internet @ 2025
        </p>
    );
}

export default Footer;